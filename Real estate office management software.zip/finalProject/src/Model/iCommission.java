package Model;

public interface iCommission {
	
	public double getCommission();

}
